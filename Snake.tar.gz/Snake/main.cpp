
#include "miniwin.h"
#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <iterator>
#include <sstream>
#include <cstdlib>
using namespace miniwin;
using namespace std;

int const costat = 9;
int const speed  = 1;
int const TAMX = 400, TAMY = 400;
struct coord{
    int x, y;
};

class bloc{
    int _x, _y;
public:
    bloc(){
        _x = 30;
        _y = 30;
    }
    bloc(coord& C){
        _x = C.x;
        _y = C.y;
    }
    void set_coord(int x, int y){
        _x = x;
        _y = y;
    }
    pair<int,int> get_coord(){
        return make_pair(_x, _y);
    }
    void pinta(){
        rectangulo_lleno(_x, _y, _x+costat, _y+costat);
    }
};
class menjar{
    bloc _M;
public:
    menjar(){
        coord C = {100, 100};
        bloc M(C);
        _M = M;
    }
        menjar(coord& C){
        bloc M(C);
        _M = M;
    }
    void set_coord(coord& C){
        bloc M(C);
        _M = M;
    }
    void respawn(){
        int x = rand() % 350, y = rand() % 350;
        int xe = x%10, ye = y%10;
        if(xe != 0){
            x = x + (10-xe);
        }
        if(ye != 0){
            y = y + (10-ye);
        }
        coord C = {x,y};
        bloc M(C);
        _M = M;

    }
    coord get_coord(){
        coord C;
        C.x = (_M.get_coord()).first;
        C.y = (_M.get_coord()).second;
        return C;
    }
    void pinta(){
        _M.pinta();
    }


};
class snake{
    list<bloc> S;
public:
    snake(){
        bloc B;
        S.push_back(B);
    }
    snake(coord& C){
        bloc B(C);
        S.push_back(B);
    }
    void pinta(){
        list<bloc>::iterator it = S.begin();
        list<bloc>::iterator it_color = S.begin();
        for(;it != S.end(); it++){
            if(it == it_color){
                color(ROJO);
            }else{
                color(AMARILLO);
            }
            (*it).pinta();
        }
    }
    //MOVIMENT
    void mov(coord& C){
        bloc B(C);
        S.push_front(B);
        S.pop_back();
    }
    //CREIX
    void creix(coord& C){
        bloc B(C);
        S.push_back(B);
    }

};
//COLISIO AMB EL MENJAR
bool colisio(coord& C, coord& M){
    if (C.x == M.x && C.y == M.y){
        return true;
    }else{
        return false;
    }
}
//COLISIO AMB PARET
void colisio_pared(coord& C){
    if(C.x < 20){
        C.x = TAMX - 30;
    }else if(C.x > TAMX - 30){
        C.x = 20;
    }else if(C.y < 20){
        C.y = TAMY - 20;
    }else if(C.y > TAMY - 20){
        C.y = 20;
    }

}
//REQUADRE DE JOC
void zonajoc(int puntuacio){
    color(AMARILLO);
    rectangulo(20, 20, TAMX - 20, TAMY -20);
    ostringstream C;
    C << puntuacio;
    texto(TAMX/2, 10, C.str());
}
int main() {
    //TAMANY FINESTRA
    vredimensiona(TAMX, TAMY);
    //POSICIO
    coord pos = {200, 150}, pos_m;

    int dx = 0, dy =0;
    int puntuacio = 0;
    bool eaten = false;

    menjar M;
    pos_m = M.get_coord();
    snake S(pos);
    zonajoc(puntuacio);

    int t = tecla();
    while(t != ESCAPE){

        if(t == ARRIBA){
            dx = 0;
            dy = -1;
        }else if(t == ABAJO){
            dx = 0;
            dy = 1;
        }else if(t == DERECHA){
            dx = 1;
            dy = 0;
        }else if(t == IZQUIERDA){
            dx = -1;
            dy = 0;
        }
        colisio_pared(pos);                         //COMPROVA SI XOCA AMB PARET
        pos.x += 10*dx*speed;                       //INCREMENT DE POSICIO
        pos.y += 10*dy*speed;
        S.mov(pos);                                 //MOVIMENT EN FUNCIÓ DE LA POSICIO

        M.pinta();                                  //
        S.pinta();                                  //      HO PINTA TOT
        zonajoc(puntuacio);                         //

        if(colisio(pos, pos_m)){
            S.creix(pos);                           // COLISIO AMB EL MENJAR
            puntuacio += 20;
            eaten = true;
        }

        refresca();
        espera(80);
        borra();                                    //PREPARACIÓ PER TORNAR A COMENÇAR EL BUCLE
        t = tecla();
        if(eaten){
            M.respawn();
            pos_m = M.get_coord();
            eaten = false;
        }

    }

    S.pinta();
    refresca();
    return 0;
}
