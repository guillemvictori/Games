#include <iostream>
using namespace std;

int main(){

    int a, b;
    while(cin >> a){

    cout << endl;
    cin >> b;
    cout << endl << a%b << endl;
    }
}
